package com.sunbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSunbaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSunbaseApplication.class, args);
	}

}
