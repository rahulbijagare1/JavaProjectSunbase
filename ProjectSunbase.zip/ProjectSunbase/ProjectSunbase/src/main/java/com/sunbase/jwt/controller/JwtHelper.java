package com.sunbase.jwt.controller;

import org.springframework.security.core.userdetails.UserDetails;

public class JwtHelper {

	public String generateToken1(UserDetails userDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public String generateToken(UserDetails userDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean validateToken(String token, UserDetails userDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getUsernameFromToken(String token) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
