package com.sunbase.jwt.controller;

public class JwtRequest {

	public String getEmail() {
		// TODO Auto-generated method stub
		
		return "user";
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return "password";
	}

	

	
	}


